from django.shortcuts import render
from . import models

def index(request):
    # Destination 1
    dest1 = models.Destination()
    dest1.price = 1000
    dest1.name = "Bihar"
    dest1.desc = "Bharat"
    dest1.img = "destination_1.jpg"

    # Destination 2
    dest2 = models.Destination()
    dest2.price = 500
    dest2.name = "Greater Noida"
    dest2.desc = "Bharat"
    dest2.img = "destination_2.jpg"

    #Destination 3
    dest3 = models.Destination()
    dest3.price = 150
    dest3.name = "West Bengal"
    dest3.desc = "Bharat"
    dest3.img = "destination_3.jpg"
    dests=[dest1,dest2,dest3]
    return render(request,"index.html",{'dests':dests})